HOSPITAL MANAGEMENT SYSTEM (Python)

Files:
- hospital_management.py : Complete runnable project
- README.txt             : Run instructions

Requirements:
- Python 3.8 or newer
- No external packages required (uses Python's built-in sqlite3 module)

Run:
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open a terminal in that folder.
4. Run: python hospital_management.py
   On Windows, if needed: py hospital_management.py

The program automatically creates hospital.db in the current working directory
when it is first run. It stores patients, doctors, appointments, and bills.

This is an educational console-based project, not a production-ready hospital
system.
