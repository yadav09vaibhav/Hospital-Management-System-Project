import sqlite3
from datetime import datetime


# -------------------- Patient Class --------------------
class Patient:
    def __init__(self, name, age, gender, phone, address):
        self.name = name
        self.age = age
        self.gender = gender
        self.phone = phone
        self.address = address


# -------------------- Doctor Class --------------------
class Doctor:
    def __init__(self, name, specialization, phone):
        self.name = name
        self.specialization = specialization
        self.phone = phone


# -------------------- Appointment Class --------------------
class Appointment:
    def __init__(self, patient_id, doctor_id, date):
        self.patient_id = patient_id
        self.doctor_id = doctor_id
        self.date = date


# -------------------- Bill Class --------------------
class Bill:
    def __init__(self, patient_id, amount, description):
        self.patient_id = patient_id
        self.amount = amount
        self.description = description


# -------------------- Hospital Management System --------------------
class HospitalManagementSystem:
    def __init__(self):
        self.conn = sqlite3.connect("hospital.db")
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.create_tables()

    def create_tables(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS patients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                age INTEGER NOT NULL,
                gender TEXT NOT NULL,
                phone TEXT NOT NULL,
                address TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS doctors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                specialization TEXT NOT NULL,
                phone TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER NOT NULL,
                doctor_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                FOREIGN KEY (patient_id) REFERENCES patients(id),
                FOREIGN KEY (doctor_id) REFERENCES doctors(id)
            );

            CREATE TABLE IF NOT EXISTS bills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                description TEXT NOT NULL,
                date TEXT NOT NULL,
                FOREIGN KEY (patient_id) REFERENCES patients(id)
            );
        """)
        self.conn.commit()

    def add_patient(self):
        print("\\n--- Register Patient ---")
        name = input("Patient name: ").strip()
        if not name:
            print("Name cannot be empty.")
            return

        try:
            age = int(input("Age: "))
            if age < 0 or age > 130:
                print("Enter a valid age.")
                return
        except ValueError:
            print("Age must be a number.")
            return

        gender = input("Gender: ").strip()
        phone = input("Phone: ").strip()
        address = input("Address: ").strip()

        if not all([gender, phone, address]):
            print("All fields are required.")
            return

        patient = Patient(name, age, gender, phone, address)
        cursor = self.conn.execute(
            """INSERT INTO patients
               (name, age, gender, phone, address)
               VALUES (?, ?, ?, ?, ?)""",
            (patient.name, patient.age, patient.gender,
             patient.phone, patient.address)
        )
        self.conn.commit()
        print("Patient registered successfully. Patient ID:",
              cursor.lastrowid)

    def add_doctor(self):
        print("\\n--- Register Doctor ---")
        name = input("Doctor name: ").strip()
        specialization = input("Specialization: ").strip()
        phone = input("Phone: ").strip()

        if not all([name, specialization, phone]):
            print("All fields are required.")
            return

        doctor = Doctor(name, specialization, phone)
        cursor = self.conn.execute(
            """INSERT INTO doctors (name, specialization, phone)
               VALUES (?, ?, ?)""",
            (doctor.name, doctor.specialization, doctor.phone)
        )
        self.conn.commit()
        print("Doctor registered successfully. Doctor ID:",
              cursor.lastrowid)

    def view_patients(self):
        rows = self.conn.execute(
            "SELECT * FROM patients ORDER BY id"
        ).fetchall()
        print("\\n--- Patient Records ---")
        if not rows:
            print("No patient records found.")
            return
        for p in rows:
            print(
                f"ID: {p[0]} | Name: {p[1]} | Age: {p[2]} | "
                f"Gender: {p[3]} | Phone: {p[4]} | Address: {p[5]}"
            )

    def view_doctors(self):
        rows = self.conn.execute(
            "SELECT * FROM doctors ORDER BY id"
        ).fetchall()
        print("\\n--- Doctor Records ---")
        if not rows:
            print("No doctor records found.")
            return
        for d in rows:
            print(
                f"ID: {d[0]} | Name: {d[1]} | "
                f"Specialization: {d[2]} | Phone: {d[3]}"
            )

    def book_appointment(self):
        print("\\n--- Book Appointment ---")
        try:
            patient_id = int(input("Patient ID: "))
            doctor_id = int(input("Doctor ID: "))
        except ValueError:
            print("IDs must be numbers.")
            return

        patient = self.conn.execute(
            "SELECT id FROM patients WHERE id = ?", (patient_id,)
        ).fetchone()
        doctor = self.conn.execute(
            "SELECT id FROM doctors WHERE id = ?", (doctor_id,)
        ).fetchone()

        if not patient:
            print("Patient not found.")
            return
        if not doctor:
            print("Doctor not found.")
            return

        date = input("Appointment date (YYYY-MM-DD): ").strip()
        try:
            datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            print("Invalid date. Use YYYY-MM-DD.")
            return

        appointment = Appointment(patient_id, doctor_id, date)
        cursor = self.conn.execute(
            """INSERT INTO appointments (patient_id, doctor_id, date)
               VALUES (?, ?, ?)""",
            (appointment.patient_id, appointment.doctor_id,
             appointment.date)
        )
        self.conn.commit()
        print("Appointment booked successfully. Appointment ID:",
              cursor.lastrowid)

    def view_appointments(self):
        rows = self.conn.execute("""
            SELECT a.id, p.name, d.name, d.specialization, a.date
            FROM appointments a
            JOIN patients p ON a.patient_id = p.id
            JOIN doctors d ON a.doctor_id = d.id
            ORDER BY a.date, a.id
        """).fetchall()
        print("\\n--- Appointment Records ---")
        if not rows:
            print("No appointments found.")
            return
        for a in rows:
            print(
                f"Appointment ID: {a[0]} | Patient: {a[1]} | "
                f"Doctor: {a[2]} ({a[3]}) | Date: {a[4]}"
            )

    def generate_bill(self):
        print("\\n--- Generate Bill ---")
        try:
            patient_id = int(input("Patient ID: "))
            amount = float(input("Bill amount (Rs.): "))
            if amount < 0:
                print("Bill amount cannot be negative.")
                return
        except ValueError:
            print("Enter a valid ID and amount.")
            return

        patient = self.conn.execute(
            "SELECT name FROM patients WHERE id = ?", (patient_id,)
        ).fetchone()
        if not patient:
            print("Patient not found.")
            return

        description = input("Bill description: ").strip()
        if not description:
            print("Description cannot be empty.")
            return

        bill = Bill(patient_id, amount, description)
        bill_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor = self.conn.execute(
            """INSERT INTO bills (patient_id, amount, description, date)
               VALUES (?, ?, ?, ?)""",
            (bill.patient_id, bill.amount, bill.description, bill_date)
        )
        self.conn.commit()

        print("\\nBill generated successfully!")
        print("Bill ID:", cursor.lastrowid)
        print("Patient:", patient[0])
        print("Description:", bill.description)
        print(f"Amount: Rs. {bill.amount:.2f}")
        print("Date:", bill_date)

    def view_bills(self):
        rows = self.conn.execute("""
            SELECT b.id, p.name, b.amount, b.description, b.date
            FROM bills b
            JOIN patients p ON b.patient_id = p.id
            ORDER BY b.id
        """).fetchall()
        print("\\n--- Billing Records ---")
        if not rows:
            print("No bills found.")
            return
        for b in rows:
            print(
                f"Bill ID: {b[0]} | Patient: {b[1]} | "
                f"Amount: Rs. {b[2]:.2f} | "
                f"Description: {b[3]} | Date: {b[4]}"
            )

    def search_patient(self):
        try:
            patient_id = int(input("Enter patient ID: "))
        except ValueError:
            print("Patient ID must be a number.")
            return

        p = self.conn.execute(
            "SELECT * FROM patients WHERE id = ?", (patient_id,)
        ).fetchone()
        if p:
            print("\\n--- Patient Details ---")
            print("Patient ID:", p[0])
            print("Name:", p[1])
            print("Age:", p[2])
            print("Gender:", p[3])
            print("Phone:", p[4])
            print("Address:", p[5])
        else:
            print("Patient not found.")

    def run(self):
        while True:
            print("\\n" + "=" * 40)
            print("     HOSPITAL MANAGEMENT SYSTEM")
            print("=" * 40)
            print("1. Register Patient")
            print("2. Register Doctor")
            print("3. View Patients")
            print("4. View Doctors")
            print("5. Book Appointment")
            print("6. View Appointments")
            print("7. Generate Bill")
            print("8. View Bills")
            print("9. Search Patient")
            print("0. Exit")

            choice = input("Enter your choice: ").strip()
            actions = {
                "1": self.add_patient,
                "2": self.add_doctor,
                "3": self.view_patients,
                "4": self.view_doctors,
                "5": self.book_appointment,
                "6": self.view_appointments,
                "7": self.generate_bill,
                "8": self.view_bills,
                "9": self.search_patient
            }

            if choice == "0":
                print("Thank you for using Hospital Management System.")
                break
            elif choice in actions:
                try:
                    actions[choice]()
                except sqlite3.Error as error:
                    self.conn.rollback()
                    print("Database error:", error)
            else:
                print("Invalid choice. Please try again.")

    def close(self):
        self.conn.close()


if __name__ == "__main__":
    hospital = HospitalManagementSystem()
    try:
        hospital.run()
    except (KeyboardInterrupt, EOFError):
        print("\\nProgram terminated.")
    finally:
        hospital.close()
